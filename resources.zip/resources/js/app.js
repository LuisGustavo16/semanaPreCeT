/*CSS geral*/
import '../css/cabecalho.css';
import '../css/tabela.css';
import '../css/formulario.css';

/*CSS especifico*/
import '../css/modalidade.css';
import '../css/treino.css';
import '../css/time.css';
import '../css/reserva.css';
import '../css/noticia.css';
import '../css/cronograma.css';
import '../css/jogo.css';
import '../css/aluno.css';
import '../css/login.css';
import '../css/mensagem.css';

/*Padrão do laravel*/
import '../scss/app.scss';
